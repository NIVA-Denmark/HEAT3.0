# HEAT3.0
The HEAT 3.0 Eutrophication Assessment Tool
https://onlinelibrary.wiley.com/doi/full/10.1111/brv.12221
